Food Delivery ETA - Final Submission

Files included:
1) Food_Delivery_ETA.ipynb
2) app.py
3) best_catboost_model.cbm
4) model_features.joblib
5) model_results.csv
6) top_features.csv
7) .streamlit/config.toml
8) requirements.txt

How to run the app:
1) Open terminal
2) cd "/Users/manansharma/Documents/New project/FINAL_SUBMISSION"
3) /opt/anaconda3/bin/python -m pip install -r requirements.txt
4) /opt/anaconda3/bin/python -m streamlit run app.py --server.port 8502
5) Open browser: http://localhost:8502

Notes:
- Model files are already trained and linked in app.py.
- Input validation is enabled.
- Geo features are auto-calculated inside app.py.
