import re

import numpy as np
import pandas as pd
import joblib
from catboost import CatBoostRegressor
import streamlit as st
import streamlit.components.v1 as components

MODEL_PATH = "/Users/manansharma/Documents/New project/best_catboost_model.cbm"
META_PATH = "/Users/manansharma/Documents/New project/model_features.joblib"

ORDER_OPTIONS = ["Meal", "Snack", "Drinks", "Buffet"]
VEHICLE_OPTIONS = ["motorcycle", "scooter", "electric_scooter", "bicycle"]


def inject_styles():
    st.markdown(
        """
        <style>
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;700&family=Manrope:wght@400;600;700&display=swap');
        :root {
            --bg-1: #fff8f0;
            --bg-2: #edf7ff;
            --text-main: #0d2238;
            --text-soft: #4e667a;
            --surface: #ffffff;
            --surface-2: #fbfdff;
            --line: #d5e1ee;
            --accent: #ff6b3d;
            --accent-deep: #e44f20;
            --mint: #11a39a;
            --mint-deep: #0d7f78;
        }
        .stApp {
            background:
              radial-gradient(900px 540px at -12% -15%, rgba(255, 107, 61, 0.18), transparent 58%),
              radial-gradient(900px 560px at 110% -12%, rgba(17, 163, 154, 0.15), transparent 56%),
              linear-gradient(180deg, var(--bg-1) 0%, var(--bg-2) 100%);
        }
        .main .block-container {
            max-width: 1120px;
            padding-top: 1.2rem;
            padding-bottom: 2rem;
        }
        h1, h2, h3 {
            font-family: "Space Grotesk", sans-serif;
            letter-spacing: -0.02em;
            color: var(--text-main) !important;
        }
        html, body, p, label, span, div {
            font-family: "Manrope", sans-serif;
            color: var(--text-main);
        }
        [data-testid="stWidgetLabel"] p,
        [data-testid="stWidgetLabel"] span {
            color: var(--text-main) !important;
            font-weight: 700 !important;
            font-size: 0.95rem !important;
        }
        .stMarkdown p, .stMarkdown span, .stText p {
            color: var(--text-main) !important;
        }
        [data-testid="stForm"] {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 22px;
            box-shadow: 0 18px 34px rgba(13, 34, 56, 0.10);
            padding: 1rem 1rem 0.4rem 1rem;
        }
        [data-baseweb="input"] > div,
        [data-baseweb="select"] > div {
            border-radius: 12px !important;
            border: 1px solid var(--line) !important;
            background: var(--surface) !important;
            min-height: 46px;
        }
        [data-baseweb="input"] input,
        [data-baseweb="input"] textarea,
        [data-baseweb="select"] input,
        [data-baseweb="select"] span,
        [data-baseweb="select"] [role="button"] {
            color: var(--text-main) !important;
            -webkit-text-fill-color: var(--text-main) !important;
            font-weight: 600 !important;
            background: transparent !important;
        }
        [data-baseweb="input"] input::placeholder,
        [data-baseweb="input"] textarea::placeholder {
            color: #70889c !important;
            opacity: 1 !important;
        }
        [data-baseweb="input"] button {
            background: #f1f6fb !important;
            color: var(--text-main) !important;
            border-left: 1px solid var(--line) !important;
        }
        [data-baseweb="input"] button:hover {
            background: #e8f0f8 !important;
        }
        [data-baseweb="input"] > div:focus-within,
        [data-baseweb="select"] > div:focus-within {
            border-color: #2a89b5 !important;
            box-shadow: 0 0 0 2px rgba(42, 137, 181, 0.16) !important;
        }
        div[data-baseweb="popover"] {
            background: #ffffff !important;
            border: 1px solid var(--line) !important;
            border-radius: 12px !important;
            box-shadow: 0 18px 30px rgba(13, 34, 56, 0.18) !important;
        }
        div[data-baseweb="popover"] * {
            color: var(--text-main) !important;
            -webkit-text-fill-color: var(--text-main) !important;
        }
        div[data-baseweb="popover"] ul,
        div[data-baseweb="popover"] [role="listbox"],
        div[data-baseweb="popover"] [data-baseweb="menu"] {
            background: #ffffff !important;
        }
        div[data-baseweb="popover"] [role="option"],
        div[data-baseweb="popover"] li {
            background: #ffffff !important;
            color: var(--text-main) !important;
            font-weight: 600 !important;
        }
        div[data-baseweb="popover"] [role="option"]:hover,
        div[data-baseweb="popover"] li:hover {
            background: #f2f8ff !important;
        }
        div[data-baseweb="popover"] [aria-selected="true"] {
            background: #e8f4ff !important;
            color: #083150 !important;
            font-weight: 700 !important;
        }
        .stButton > button {
            border: none;
            border-radius: 999px;
            color: #ffffff;
            background: linear-gradient(90deg, var(--accent) 0%, var(--accent-deep) 100%);
            box-shadow: 0 12px 22px rgba(228, 79, 32, 0.28);
            font-weight: 700;
            padding: 0.55rem 1.4rem;
            transition: transform 140ms ease, box-shadow 140ms ease, filter 140ms ease;
        }
        .stButton > button:hover {
            transform: translateY(-1px);
            box-shadow: 0 14px 24px rgba(228, 79, 32, 0.36);
            filter: brightness(1.03);
        }
        .stButton > button:active {
            transform: translateY(0);
        }
        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(8px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .fade-in { animation: fadeUp 0.45s ease-out both; }
        .hero {
            border-radius: 22px;
            padding: 1.1rem 1.2rem;
            margin-bottom: 1rem;
            background: linear-gradient(135deg, #ffffff 0%, #fff6f1 42%, #f1fffc 100%);
            border: 1px solid var(--line);
            box-shadow: 0 16px 30px rgba(13, 34, 56, 0.10);
        }
        .badge-row {
            margin-top: 0.5rem;
            display: flex;
            gap: 0.45rem;
            flex-wrap: wrap;
        }
        .badge {
            background: rgba(17, 163, 154, 0.12);
            color: #0b5f59;
            padding: 0.26rem 0.62rem;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
        }
        .metric-card {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 16px;
            padding: 0.8rem 0.9rem;
            box-shadow: 0 9px 22px rgba(13, 34, 56, 0.08);
            min-height: 90px;
        }
        .metric-label {
            display: block;
            font-size: 0.8rem;
            color: var(--text-soft);
            margin-bottom: 0.2rem;
            font-weight: 600;
        }
        .metric-value {
            font-size: 1.25rem;
            font-weight: 800;
            color: var(--text-main);
        }
        .result-card {
            border-radius: 18px;
            background: linear-gradient(135deg, #ff6b3d 0%, #ff8a51 46%, #11a39a 100%);
            border: 1px solid rgba(204, 95, 53, 0.35);
            padding: 1rem;
            margin-top: 0.45rem;
            box-shadow: 0 14px 28px rgba(23, 98, 109, 0.28);
        }
        .result-big {
            font-family: "Space Grotesk", sans-serif;
            font-size: 2rem;
            font-weight: 700;
            color: #ffffff;
            line-height: 1.05;
        }
        .result-tag {
            display: inline-block;
            margin-top: 0.35rem;
            border-radius: 999px;
            background: rgba(255, 255, 255, 0.24);
            color: #ffffff;
            padding: 0.2rem 0.6rem;
            font-size: 0.78rem;
            font-weight: 700;
        }
        [data-testid="stAlert"] {
            border-radius: 12px !important;
            border: 1px solid var(--line) !important;
        }
        .stDataFrame {
            border: 1px solid var(--line);
            border-radius: 12px;
        }
        [data-testid="stExpander"] {
            background: #ffffff;
            border: 1px solid var(--line);
            border-radius: 12px;
        }
        [data-testid="stExpander"] summary {
            color: var(--text-main) !important;
            font-weight: 700 !important;
        }
        @media (max-width: 900px) {
            .main .block-container { padding-top: 0.8rem; }
            .hero { padding: 0.85rem 0.9rem; }
            .result-big { font-size: 1.65rem; }
        }
        </style>
        """,
        unsafe_allow_html=True,
    )


def haversine_km(lat1, lon1, lat2, lon2):
    radius = 6371.0
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = np.sin(dlat / 2.0) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin(dlon / 2.0) ** 2
    c = 2 * np.arcsin(np.sqrt(a))
    return radius * c


def distance_bucket(distance_km):
    if distance_km <= 2:
        return "very_short"
    if distance_km <= 5:
        return "short"
    if distance_km <= 10:
        return "medium"
    if distance_km <= 20:
        return "long"
    return "very_long"


def is_valid_india_geo(r_lat, r_lon, d_lat, d_lon):
    return (
        6 <= r_lat <= 38
        and 68 <= r_lon <= 98
        and 6 <= d_lat <= 38
        and 68 <= d_lon <= 98
    )


def make_model_row(raw_inputs):
    r_lat = raw_inputs["restaurant_latitude"]
    r_lon = raw_inputs["restaurant_longitude"]
    d_lat = raw_inputs["delivery_location_latitude"]
    d_lon = raw_inputs["delivery_location_longitude"]

    lat_diff_abs = abs(d_lat - r_lat)
    lon_diff_abs = abs(d_lon - r_lon)
    manhattan_proxy_km = (lat_diff_abs + lon_diff_abs) * 111
    hv_km = float(haversine_km(r_lat, r_lon, d_lat, d_lon))
    geo_valid = is_valid_india_geo(r_lat, r_lon, d_lat, d_lon)

    row = {
        "delivery_person_age": raw_inputs["delivery_person_age"],
        "delivery_person_ratings": raw_inputs["delivery_person_ratings"],
        "restaurant_latitude": r_lat,
        "restaurant_longitude": r_lon,
        "delivery_location_latitude": d_lat,
        "delivery_location_longitude": d_lon,
        "type_of_order": raw_inputs["type_of_order"],
        "type_of_vehicle": raw_inputs["type_of_vehicle"],
        "city": raw_inputs["city"],
        "restaurant_code": raw_inputs["restaurant_code"],
        "rider_code": raw_inputs["rider_code"],
        "geo_valid": geo_valid,
        "haversine_km": hv_km,
        "lat_diff_abs": lat_diff_abs,
        "lon_diff_abs": lon_diff_abs,
        "manhattan_proxy_km": manhattan_proxy_km,
        "distance_bucket": distance_bucket(hv_km),
    }
    return row, geo_valid


def sanitize_code(text, uppercase=True):
    cleaned = re.sub(r"[^A-Za-z0-9]", "", text.strip())
    if uppercase:
        cleaned = cleaned.upper()
    return cleaned


def eta_tag(eta_minutes):
    if eta_minutes <= 20:
        return "Rapid Delivery"
    if eta_minutes <= 35:
        return "On-Track Delivery"
    return "Potential Delay"


def trigger_haptic():
    components.html(
        """
        <script>
        if (window.navigator && "vibrate" in window.navigator) {
            window.navigator.vibrate([110, 45, 110]);
        }
        </script>
        """,
        height=0,
        width=0,
    )


def load_artifacts():
    loaded_model = CatBoostRegressor()
    loaded_model.load_model(MODEL_PATH)
    loaded_meta = joblib.load(META_PATH)
    return loaded_model, loaded_meta["feature_columns"], loaded_meta["categorical_columns"]


st.set_page_config(page_title="ETA Studio", page_icon="🍔", layout="wide")
inject_styles()

if "model_bundle" not in st.session_state:
    try:
        st.session_state["model_bundle"] = load_artifacts()
    except Exception as exc:
        st.error(f"Model files could not be loaded: {exc}")
        st.stop()

model, feature_cols, cat_cols = st.session_state["model_bundle"]

st.markdown(
    """
    <div class="hero fade-in">
      <h2 style="margin:0;">Food Delivery ETA Studio</h2>
      <p style="margin:0.25rem 0 0 0; color:#42586a;">
        Clean prediction flow with live geo intelligence and model-grade validation.
      </p>
      <div class="badge-row">
        <span class="badge">CatBoost Model</span>
        <span class="badge">Geo Features</span>
        <span class="badge">Input Validation</span>
      </div>
    </div>
    """,
    unsafe_allow_html=True,
)

with st.form("eta_form", clear_on_submit=False):
    left, right = st.columns(2, gap="large")
    with left:
        st.subheader("Partner and Order")
        delivery_person_age = st.number_input(
            "Delivery Partner Age", min_value=18, max_value=60, value=28, step=1
        )
        delivery_person_ratings = st.number_input(
            "Delivery Partner Rating", min_value=1.0, max_value=5.0, value=4.7, step=0.1, format="%.1f"
        )
        type_of_order = st.selectbox("Type of Order", ORDER_OPTIONS)
        type_of_vehicle = st.selectbox("Type of Vehicle", VEHICLE_OPTIONS)
        city_raw = st.text_input("City Code", placeholder="INDO / BANG / HYD")
        restaurant_code_raw = st.text_input("Restaurant Code", placeholder="16")
        rider_code_raw = st.text_input("Rider Code", placeholder="02")

    with right:
        st.subheader("Restaurant and Delivery Coordinates")
        restaurant_latitude = st.number_input(
            "Restaurant Latitude", min_value=-90.0, max_value=90.0, value=22.745049, format="%.6f"
        )
        restaurant_longitude = st.number_input(
            "Restaurant Longitude", min_value=-180.0, max_value=180.0, value=75.892471, format="%.6f"
        )
        delivery_location_latitude = st.number_input(
            "Delivery Latitude", min_value=-90.0, max_value=90.0, value=22.765049, format="%.6f"
        )
        delivery_location_longitude = st.number_input(
            "Delivery Longitude", min_value=-180.0, max_value=180.0, value=75.912471, format="%.6f"
        )

    submitted = st.form_submit_button("Predict ETA", use_container_width=True)

preview_distance = float(
    haversine_km(
        restaurant_latitude,
        restaurant_longitude,
        delivery_location_latitude,
        delivery_location_longitude,
    )
)
preview_bucket = distance_bucket(preview_distance)
preview_geo_valid = is_valid_india_geo(
    restaurant_latitude,
    restaurant_longitude,
    delivery_location_latitude,
    delivery_location_longitude,
)

card_1, card_2, card_3 = st.columns(3, gap="medium")
card_1.markdown(
    f"""
    <div class="metric-card fade-in">
      <span class="metric-label">Estimated Route Distance</span>
      <span class="metric-value">{preview_distance:.2f} km</span>
    </div>
    """,
    unsafe_allow_html=True,
)
card_2.markdown(
    f"""
    <div class="metric-card fade-in">
      <span class="metric-label">Distance Category</span>
      <span class="metric-value">{preview_bucket.replace("_", " ").title()}</span>
    </div>
    """,
    unsafe_allow_html=True,
)
card_3.markdown(
    f"""
    <div class="metric-card fade-in">
      <span class="metric-label">Coordinate Quality</span>
      <span class="metric-value">{"Valid" if preview_geo_valid else "Invalid"}</span>
    </div>
    """,
    unsafe_allow_html=True,
)

if submitted:
    city = sanitize_code(city_raw, uppercase=True)
    restaurant_code = sanitize_code(restaurant_code_raw, uppercase=False)
    rider_code = sanitize_code(rider_code_raw, uppercase=False)

    missing = []
    if not city:
        missing.append("City Code")
    if not restaurant_code:
        missing.append("Restaurant Code")
    if not rider_code:
        missing.append("Rider Code")
    if missing:
        st.error(f"Please fill required fields: {', '.join(missing)}")
        st.stop()

    if not preview_geo_valid:
        st.error("Coordinates are outside expected data geography. Please provide valid points.")
        st.stop()

    raw = {
        "delivery_person_age": int(delivery_person_age),
        "delivery_person_ratings": float(delivery_person_ratings),
        "restaurant_latitude": float(restaurant_latitude),
        "restaurant_longitude": float(restaurant_longitude),
        "delivery_location_latitude": float(delivery_location_latitude),
        "delivery_location_longitude": float(delivery_location_longitude),
        "type_of_order": type_of_order,
        "type_of_vehicle": type_of_vehicle,
        "city": city,
        "restaurant_code": restaurant_code,
        "rider_code": rider_code,
    }

    row, _ = make_model_row(raw)
    x = pd.DataFrame([row], columns=feature_cols)
    for c in cat_cols:
        x[c] = x[c].astype(str)

    try:
        pred = float(model.predict(x)[0])
    except Exception as exc:
        st.error(f"Prediction failed: {exc}")
        st.stop()

    trigger_haptic()
    st.toast("Prediction complete", icon="✅")
    st.markdown(
        f"""
        <div class="result-card fade-in">
          <div style="font-size:0.84rem; color:#f2fffc; font-weight:700;">Predicted Delivery Time</div>
          <div class="result-big">{pred:.2f} minutes</div>
          <span class="result-tag">{eta_tag(pred)}</span>
        </div>
        """,
        unsafe_allow_html=True,
    )

    with st.expander("View computed trip features"):
        st.dataframe(
            pd.DataFrame(
                [
                    {
                        "haversine_km": row["haversine_km"],
                        "distance_bucket": row["distance_bucket"],
                        "manhattan_proxy_km": row["manhattan_proxy_km"],
                        "lat_diff_abs": row["lat_diff_abs"],
                        "lon_diff_abs": row["lon_diff_abs"],
                        "geo_valid": row["geo_valid"],
                    }
                ]
            ),
            use_container_width=True,
            hide_index=True,
        )
